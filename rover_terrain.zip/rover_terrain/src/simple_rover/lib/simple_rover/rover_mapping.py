#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan, PointCloud2
from sensor_msgs_py import point_cloud2
from nav_msgs.msg import OccupancyGrid
import numpy as np
import math

class RoverMapping(Node):
    def __init__(self):
        super().__init__('rover_mapping')
        
        # Create subscribers
        self.scan_sub = self.create_subscription(
            LaserScan,
            'scan',
            self.scan_callback,
            10)
        
        # Create publishers
        self.point_cloud_pub = self.create_publisher(
            PointCloud2,
            'terrain_point_cloud',
            10)
        
        self.map_pub = self.create_publisher(
            OccupancyGrid,
            'terrain_map',
            10)
        
        # Initialize map parameters
        self.map_resolution = 0.1  # meters per pixel
        self.map_width = 100  # pixels
        self.map_height = 100  # pixels
        self.map_origin_x = -5.0  # meters
        self.map_origin_y = -5.0  # meters
        
        # Initialize map
        self.map = np.zeros((self.map_height, self.map_width), dtype=np.int8)
        
        self.get_logger().info('Rover mapping node initialized')
    
    def scan_callback(self, msg):
        # Convert laser scan to point cloud
        points = []
        for i, r in enumerate(msg.ranges):
            if r < msg.range_min or r > msg.range_max:
                continue
            
            angle = msg.angle_min + i * msg.angle_increment
            x = r * math.cos(angle)
            y = r * math.sin(angle)
            z = 0.0  # Assuming 2D scan
            
            points.append([x, y, z])
        
        # Create point cloud message
        header = msg.header
        fields = [
            point_cloud2.PointField(name='x', offset=0, datatype=point_cloud2.PointField.FLOAT32, count=1),
            point_cloud2.PointField(name='y', offset=4, datatype=point_cloud2.PointField.FLOAT32, count=1),
            point_cloud2.PointField(name='z', offset=8, datatype=point_cloud2.PointField.FLOAT32, count=1)
        ]
        
        pc2_msg = point_cloud2.create_cloud(header, fields, points)
        self.point_cloud_pub.publish(pc2_msg)
        
        # Update map
        self.update_map(points)
    
    def update_map(self, points):
        # Convert points to map coordinates
        for x, y, _ in points:
            map_x = int((x - self.map_origin_x) / self.map_resolution)
            map_y = int((y - self.map_origin_y) / self.map_resolution)
            
            if 0 <= map_x < self.map_width and 0 <= map_y < self.map_height:
                self.map[map_y, map_x] = 100  # Mark as occupied
        
        # Create occupancy grid message
        map_msg = OccupancyGrid()
        map_msg.header.frame_id = 'odom'
        map_msg.header.stamp = self.get_clock().now().to_msg()
        map_msg.info.resolution = self.map_resolution
        map_msg.info.width = self.map_width
        map_msg.info.height = self.map_height
        map_msg.info.origin.position.x = self.map_origin_x
        map_msg.info.origin.position.y = self.map_origin_y
        map_msg.info.origin.position.z = 0.0
        map_msg.info.origin.orientation.w = 1.0
        
        map_msg.data = self.map.flatten().tolist()
        self.map_pub.publish(map_msg)

def main(args=None):
    rclpy.init(args=args)
    node = RoverMapping()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main() 