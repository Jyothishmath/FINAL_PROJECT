#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import sys
import select
import termios
import tty

class RoverNavigation(Node):
    def __init__(self):
        super().__init__('rover_navigation')
        
        # Create publisher for velocity commands
        self.cmd_vel_pub = self.create_publisher(
            Twist,
            'cmd_vel',
            10)
        
        # Initialize velocity message
        self.twist = Twist()
        
        # Save terminal settings
        self.settings = termios.tcgetattr(sys.stdin)
        
        self.get_logger().info('Rover navigation node initialized')
        self.get_logger().info('Use WASD keys to control the rover:')
        self.get_logger().info('W: Move forward')
        self.get_logger().info('S: Move backward')
        self.get_logger().info('A: Turn left')
        self.get_logger().info('D: Turn right')
        self.get_logger().info('Q: Quit')
        
        # Start keyboard control loop
        self.keyboard_control()
    
    def get_key(self):
        tty.setraw(sys.stdin.fileno())
        select.select([sys.stdin], [], [], 0)
        key = sys.stdin.read(1)
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)
        return key
    
    def keyboard_control(self):
        try:
            while rclpy.ok():
                key = self.get_key()
                
                if key == 'w':
                    self.twist.linear.x = 0.5
                    self.twist.angular.z = 0.0
                elif key == 's':
                    self.twist.linear.x = -0.5
                    self.twist.angular.z = 0.0
                elif key == 'a':
                    self.twist.linear.x = 0.0
                    self.twist.angular.z = 0.5
                elif key == 'd':
                    self.twist.linear.x = 0.0
                    self.twist.angular.z = -0.5
                elif key == 'q':
                    self.twist.linear.x = 0.0
                    self.twist.angular.z = 0.0
                    self.cmd_vel_pub.publish(self.twist)
                    break
                else:
                    self.twist.linear.x = 0.0
                    self.twist.angular.z = 0.0
                
                self.cmd_vel_pub.publish(self.twist)
        
        finally:
            # Restore terminal settings
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)
            
            # Stop the rover
            self.twist.linear.x = 0.0
            self.twist.angular.z = 0.0
            self.cmd_vel_pub.publish(self.twist)

def main(args=None):
    rclpy.init(args=args)
    node = RoverNavigation()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main() 