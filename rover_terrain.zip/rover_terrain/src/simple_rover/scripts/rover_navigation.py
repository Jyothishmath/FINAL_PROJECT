#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
import random
import math
import time

class RoverNavigation(Node):
    def __init__(self):
        super().__init__('rover_navigation')
        
        # Declare parameters
        self.declare_parameter('min_obstacle_distance', 0.5)
        self.declare_parameter('explore_speed', 0.1)
        self.declare_parameter('turn_speed', 0.5)
        self.declare_parameter('avoid_factor', 0.5)
        
        # Create velocity publisher
        self.cmd_vel_publisher = self.create_publisher(Twist, '/cmd_vel', 10)
        
        # Create laser scan subscriber for obstacle avoidance
        self.scan_subscriber = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            10)
            
        # Create odometry subscriber for position tracking
        self.odom_subscriber = self.create_subscription(
            Odometry,
            '/odom',
            self.odom_callback,
            10)
        
        # Initialize navigation parameters
        self.linear_velocity = 0.1  # Slower default speed
        self.angular_velocity = 0.0
        self.obstacle_detected = False
        self.obstacle_direction = 0.0
        self.last_direction_change = time.time()
        self.direction_change_interval = 10.0  # Change direction less frequently
        self.scan_data = None
        
        # Get parameters from launch file
        self.min_obstacle_distance = self.get_parameter('min_obstacle_distance').value
        self.turn_strength = self.get_parameter('avoid_factor').value
        
        # Position tracking
        self.current_x = 0.0
        self.current_y = 0.0
        self.current_linear_vel = 0.0
        self.current_angular_vel = 0.0
        
        # Terrain boundaries (in meters)
        self.boundary_x_min = -40.0
        self.boundary_x_max = 40.0
        self.boundary_y_min = -40.0
        self.boundary_y_max = 40.0
        self.boundary_margin = 8.0  # Increased margin
        self.boundary_detected = False
        self.boundary_turn_direction = 1.0  # Default turn direction when boundary detected
        
        # Add state machine for more predictable behavior
        self.state = "EXPLORE"  # States: EXPLORE, AVOID_OBSTACLE, AVOID_BOUNDARY
        self.state_timer = time.time()
        self.state_timeout = 5.0  # Longer timeout to avoid rapid state changes
        
        # Filter for obstacle detection
        self.obstacle_filter_size = 5  # Number of consecutive detections needed
        self.obstacle_count = 0
        self.filtered_obstacle_detected = False
        
        # Start navigation
        self.timer = self.create_timer(0.1, self.navigate)
        self.get_logger().info('Rover Navigation Node Started')
        self.get_logger().info(f'Using min_obstacle_distance: {self.min_obstacle_distance}')

    def odom_callback(self, msg):
        """Track rover position and velocity from odometry data"""
        self.current_x = msg.pose.pose.position.x
        self.current_y = msg.pose.pose.position.y
        self.current_linear_vel = msg.twist.twist.linear.x
        self.current_angular_vel = msg.twist.twist.angular.z
        
        # Check if rover is approaching terrain boundaries
        self.check_boundaries()
        
        # Debug velocity info
        if random.random() < 0.05:  # Log only occasionally to avoid flooding
            self.get_logger().info(f'Current position: x={self.current_x:.2f}, y={self.current_y:.2f}, velocity: linear={self.current_linear_vel:.2f}, angular={self.current_angular_vel:.2f}')

    def check_boundaries(self):
        """Check if rover is approaching terrain boundaries"""
        self.boundary_detected = False
        
        # Check X boundaries
        if self.current_x > (self.boundary_x_max - self.boundary_margin):
            self.boundary_detected = True
            self.boundary_turn_direction = -1.0  # Turn left
            self.get_logger().info(f'Approaching right boundary at x={self.current_x:.2f}')
        elif self.current_x < (self.boundary_x_min + self.boundary_margin):
            self.boundary_detected = True
            self.boundary_turn_direction = 1.0  # Turn right
            self.get_logger().info(f'Approaching left boundary at x={self.current_x:.2f}')
            
        # Check Y boundaries
        if self.current_y > (self.boundary_y_max - self.boundary_margin):
            self.boundary_detected = True
            self.boundary_turn_direction = -1.0  # Turn left
            self.get_logger().info(f'Approaching top boundary at y={self.current_y:.2f}')
        elif self.current_y < (self.boundary_y_min + self.boundary_margin):
            self.boundary_detected = True
            self.boundary_turn_direction = 1.0  # Turn right
            self.get_logger().info(f'Approaching bottom boundary at y={self.current_y:.2f}')

    def scan_callback(self, msg):
        """Process laser scan data for obstacle detection"""
        self.scan_data = msg
        
        # Check for obstacles in front with a narrower angle (reduce sensitivity)
        front_angle = 45  # Reduced from 70 degrees to each side
        front_ranges = []
        
        # Assuming 1 degree resolution
        if len(msg.ranges) >= 360:
            front_ranges = msg.ranges[:front_angle] + msg.ranges[360-front_angle:]
        
        # Reset obstacle detection
        self.obstacle_detected = False
        min_distance = float('inf')
        min_angle = 0
        
        # Find the closest obstacle
        for i, distance in enumerate(front_ranges):
            # Filter out invalid readings and very close readings (likely noise)
            if (not math.isinf(distance) and 
                not math.isnan(distance) and 
                distance > msg.range_min + 0.05 and  # Add margin to minimum range
                distance < msg.range_max):
                if distance < min_distance:
                    min_distance = distance
                    # Calculate angle: negative is left, positive is right
                    min_angle = i if i < front_angle else (i - 360)
        
        # Check if the closest obstacle is within our threshold
        if min_distance < self.min_obstacle_distance:
            self.obstacle_count += 1
            if self.obstacle_count >= self.obstacle_filter_size:
                self.obstacle_detected = True
                self.filtered_obstacle_detected = True
                self.obstacle_direction = min_angle / front_angle
                self.get_logger().info(f'Obstacle detected at distance: {min_distance:.2f}m, direction: {self.obstacle_direction:.2f}')
        else:
            self.obstacle_count = 0
            self.filtered_obstacle_detected = False

    def navigate(self):
        """Main navigation logic using state machine"""
        current_time = time.time()
        
        # State machine transitions
        if self.state == "EXPLORE":
            if self.boundary_detected:
                self.state = "AVOID_BOUNDARY"
                self.state_timer = current_time
                self.get_logger().info("Changing state: EXPLORE -> AVOID_BOUNDARY")
            elif self.filtered_obstacle_detected:  # Use filtered detection
                self.state = "AVOID_OBSTACLE"
                self.state_timer = current_time
                self.get_logger().info("Changing state: EXPLORE -> AVOID_OBSTACLE")
            elif current_time - self.last_direction_change > self.direction_change_interval:
                self.angular_velocity = random.uniform(-0.08, 0.08)  # Very gentle turns
                self.linear_velocity = self.get_parameter('explore_speed').value
                self.last_direction_change = current_time
                self.get_logger().info(f'Changing direction, linear: {self.linear_velocity:.2f}, angular: {self.angular_velocity:.2f}')
        
        elif self.state == "AVOID_BOUNDARY":
            # Check if we're clear of boundary or timeout
            if not self.boundary_detected or (current_time - self.state_timer > self.state_timeout):
                self.state = "EXPLORE"
                self.get_logger().info("Changing state: AVOID_BOUNDARY -> EXPLORE")
            # If still avoiding boundary but another boundary is detected, update timer
            elif self.boundary_detected:
                self.state_timer = current_time
        
        elif self.state == "AVOID_OBSTACLE":
            # Check if we're clear of obstacle or timeout
            if not self.filtered_obstacle_detected or (current_time - self.state_timer > self.state_timeout):
                self.state = "EXPLORE"
                self.get_logger().info("Changing state: AVOID_OBSTACLE -> EXPLORE")
            # If still avoiding obstacle but another obstacle is detected, update timer
            elif self.filtered_obstacle_detected:
                self.state_timer = current_time
        
        # State behaviors
        if self.state == "AVOID_BOUNDARY":
            # Turn away from boundary
            self.angular_velocity = 0.2 * self.boundary_turn_direction  # Gentler turning
            self.linear_velocity = 0.05  # Very slow when avoiding boundaries
            self.get_logger().info(f'Avoiding boundary, turning with angular velocity: {self.angular_velocity}')
        
        elif self.state == "AVOID_OBSTACLE":
            # Turn away from obstacle more gently
            turn_speed = self.get_parameter('turn_speed').value
            self.angular_velocity = -turn_speed * self.obstacle_direction * self.turn_strength
            
            # Slow down when obstacles are close
            self.linear_velocity = 0.05  # Very slow when avoiding obstacles
            
            self.get_logger().info(f'Avoiding obstacle, turning with angular velocity: {self.angular_velocity}')
        
        elif self.state == "EXPLORE":
            # Normal exploration - keep current velocities or set new ones at direction change interval
            pass
        
        # Publish velocity commands
        self.publish_velocity()

    def publish_velocity(self):
        """Publish velocity commands to cmd_vel topic"""
        msg = Twist()
        msg.linear.x = self.linear_velocity
        msg.angular.z = self.angular_velocity
        self.cmd_vel_publisher.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    rover_navigation = RoverNavigation()
    try:
        rclpy.spin(rover_navigation)
    except KeyboardInterrupt:
        print('Navigation stopped by user')
    finally:
        # Stop the rover before shutting down
        stop_msg = Twist()
        stop_msg.linear.x = 0.0
        stop_msg.angular.z = 0.0
        rover_navigation.cmd_vel_publisher.publish(stop_msg)
        rover_navigation.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main() 