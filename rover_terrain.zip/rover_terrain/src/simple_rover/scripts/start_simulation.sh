#!/bin/bash

# Kill any running Gazebo processes
echo "Cleaning up existing Gazebo and ROS processes..."
pkill -f gazebo
pkill -f gzserver
pkill -f gzclient
pkill -f rviz2
sleep 2

# Source ROS environment
echo "Sourcing ROS environment..."
source /opt/ros/humble/setup.bash
source ~/FINAL_WORKING_BACKUP/install/setup.bash

# Build the workspace if needed
echo "Building workspace..."
cd ~/FINAL_WORKING_BACKUP
colcon build --packages-select simple_rover

# Source the workspace again after building
source ~/FINAL_WORKING_BACKUP/install/setup.bash

# Make script files executable
echo "Making scripts executable..."
chmod +x ~/FINAL_WORKING_BACKUP/src/simple_rover/scripts/*.py

# Launch the simulation
echo "Starting Mars rover simulation..."
ros2 launch simple_rover rover_sim.launch.py

echo "Simulation terminated." 