#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan, PointCloud2
from sensor_msgs_py import point_cloud2
from geometry_msgs.msg import Point32, TransformStamped
from std_msgs.msg import Header, ColorRGBA
from sensor_msgs.msg import PointField
from nav_msgs.msg import OccupancyGrid
from tf2_ros import TransformException
from tf2_ros.buffer import Buffer
from tf2_ros.transform_listener import TransformListener
from visualization_msgs.msg import Marker, MarkerArray
import numpy as np
import math
import struct

class RoverMapping(Node):
    def __init__(self):
        super().__init__('rover_mapping')
        
        # Create publishers
        self.point_cloud_publisher = self.create_publisher(
            PointCloud2, '/terrain_point_cloud', 10)
        
        self.occupancy_grid_publisher = self.create_publisher(
            OccupancyGrid, '/terrain_map', 10)
            
        # Publisher for visualization markers
        self.marker_publisher = self.create_publisher(
            MarkerArray, '/mapping_markers', 10)
        
        # Create subscription to laser scan
        self.scan_subscription = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            10)
        
        # Initialize TF listener
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        
        # Initialize map parameters - increased resolution for better visualization
        self.map_resolution = 0.05  # meters per cell (was 0.1)
        self.map_width = 2000  # cells (was 1000)
        self.map_height = 2000  # cells (was 1000)
        self.map_origin_x = -50.0  # meters
        self.map_origin_y = -50.0  # meters
        
        # Initialize occupancy grid
        self.occupancy_grid = np.zeros((self.map_height, self.map_width), dtype=np.int8)
        self.occupancy_grid.fill(-1)  # -1 means unknown
        
        # Initialize point cloud data
        self.points = []
        self.point_colors = []  # Add colors for better visualization
        
        # Timer for publishing map
        self.map_timer = self.create_timer(0.5, self.publish_map)  # Increased frequency (was 1.0)
        
        # Debug info
        self.last_scan_time = self.get_clock().now()
        self.scan_count = 0
        
        # Track rover path for visualization
        self.rover_path = []
        self.last_position = None
        self.path_marker_id = 0
        
        self.get_logger().info('Rover Mapping Node Started')

    def scan_callback(self, msg):
        """Process laser scan data and update the map"""
        # Debug info
        current_time = self.get_clock().now()
        self.scan_count += 1
        if self.scan_count % 10 == 0:
            self.get_logger().info(f'Received scan #{self.scan_count}')
        
        try:
            # Get transform from lidar to map frame
            transform = self.tf_buffer.lookup_transform(
                'odom',
                msg.header.frame_id,
                msg.header.stamp,
                timeout=rclpy.duration.Duration(seconds=1.0))
            
            # Extract robot position
            robot_x = transform.transform.translation.x
            robot_y = transform.transform.translation.y
            robot_z = transform.transform.translation.z
            
            # Extract robot orientation (simplified)
            robot_yaw = 2.0 * math.atan2(transform.transform.rotation.z,
                                        transform.transform.rotation.w)
            
            # Track rover path
            if self.last_position is None or math.sqrt(
                (robot_x - self.last_position[0])**2 + 
                (robot_y - self.last_position[1])**2) > 0.2:
                self.rover_path.append((robot_x, robot_y, robot_z))
                self.last_position = (robot_x, robot_y, robot_z)
            
            # Process scan data
            points = []
            point_colors = []
            obstacle_points = []
            
            for i, distance in enumerate(msg.ranges):
                # Skip invalid measurements
                if math.isinf(distance) or math.isnan(distance) or distance < msg.range_min or distance > msg.range_max:
                    continue
                
                # Calculate angle
                angle = msg.angle_min + i * msg.angle_increment
                
                # Calculate point position in lidar frame
                point_x = distance * math.cos(angle)
                point_y = distance * math.sin(angle)
                
                # Transform to robot frame
                world_x = robot_x + point_x * math.cos(robot_yaw) - point_y * math.sin(robot_yaw)
                world_y = robot_y + point_x * math.sin(robot_yaw) + point_y * math.cos(robot_yaw)
                world_z = robot_z + 0.0  # Assuming flat terrain
                
                # Add to point cloud with color based on distance
                points.append([world_x, world_y, world_z])
                
                # Color gradient based on distance (red close, blue far)
                normalized_distance = min(1.0, distance / msg.range_max)
                r = 1.0 - normalized_distance
                g = 0.0
                b = normalized_distance
                point_colors.append([r, g, b, 1.0])
                
                obstacle_points.append((world_x, world_y))
                
                # Update occupancy grid
                grid_x = int((world_x - self.map_origin_x) / self.map_resolution)
                grid_y = int((world_y - self.map_origin_y) / self.map_resolution)
                
                # Check if point is within grid bounds
                if 0 <= grid_x < self.map_width and 0 <= grid_y < self.map_height:
                    self.occupancy_grid[grid_y, grid_x] = 100  # 100 means occupied
                    
                    # Mark surrounding cells as free
                    self.mark_free_space(robot_x, robot_y, world_x, world_y)
            
            # Store points for point cloud publishing
            self.points = points
            self.point_colors = point_colors
            
            # Publish point cloud
            self.publish_point_cloud()
            
            # Publish visualization markers
            self.publish_markers(robot_x, robot_y, obstacle_points)
            
            if len(points) > 0:
                self.get_logger().info(f'Processed {len(points)} valid scan points')
            
        except TransformException as ex:
            self.get_logger().warn(f'Could not transform: {ex}')
    
    def mark_free_space(self, robot_x, robot_y, obstacle_x, obstacle_y):
        """Mark cells between robot and obstacle as free space"""
        # Convert robot position to grid coordinates
        robot_grid_x = int((robot_x - self.map_origin_x) / self.map_resolution)
        robot_grid_y = int((robot_y - self.map_origin_y) / self.map_resolution)
        
        # Convert obstacle position to grid coordinates
        obstacle_grid_x = int((obstacle_x - self.map_origin_x) / self.map_resolution)
        obstacle_grid_y = int((obstacle_y - self.map_origin_y) / self.map_resolution)
        
        # Use Bresenham's line algorithm to mark cells as free
        dx = abs(obstacle_grid_x - robot_grid_x)
        dy = abs(obstacle_grid_y - robot_grid_y)
        sx = 1 if robot_grid_x < obstacle_grid_x else -1
        sy = 1 if robot_grid_y < obstacle_grid_y else -1
        err = dx - dy
        
        x, y = robot_grid_x, robot_grid_y
        
        while (x != obstacle_grid_x or y != obstacle_grid_y):
            if 0 <= x < self.map_width and 0 <= y < self.map_height:
                # Only mark as free if it's unknown (-1)
                if self.occupancy_grid[y, x] == -1:
                    self.occupancy_grid[y, x] = 0  # 0 means free
            
            e2 = 2 * err
            if e2 > -dy:
                err -= dy
                x += sx
            if e2 < dx:
                err += dx
                y += sy

    def publish_point_cloud(self):
        """Publish point cloud data with colors"""
        if not self.points:
            return
            
        # Create point cloud header
        header = Header()
        header.stamp = self.get_clock().now().to_msg()
        header.frame_id = 'odom'
        
        # Define point cloud fields with RGB color
        fields = [
            PointField(name='x', offset=0, datatype=PointField.FLOAT32, count=1),
            PointField(name='y', offset=4, datatype=PointField.FLOAT32, count=1),
            PointField(name='z', offset=8, datatype=PointField.FLOAT32, count=1),
            PointField(name='r', offset=12, datatype=PointField.FLOAT32, count=1),
            PointField(name='g', offset=16, datatype=PointField.FLOAT32, count=1),
            PointField(name='b', offset=20, datatype=PointField.FLOAT32, count=1),
            PointField(name='a', offset=24, datatype=PointField.FLOAT32, count=1),
        ]
        
        # Combine points and colors
        colored_points = []
        for i in range(len(self.points)):
            point = self.points[i]
            color = self.point_colors[i]
            colored_points.append(point + color)
        
        # Create point cloud message
        pc2_msg = point_cloud2.create_cloud(header, fields, colored_points)
        
        # Publish point cloud
        self.point_cloud_publisher.publish(pc2_msg)
        
    def publish_markers(self, robot_x, robot_y, obstacle_points):
        """Publish visualization markers for debugging"""
        marker_array = MarkerArray()
        
        # Robot position marker
        robot_marker = Marker()
        robot_marker.header.frame_id = "odom"
        robot_marker.header.stamp = self.get_clock().now().to_msg()
        robot_marker.ns = "robot_position"
        robot_marker.id = 0
        robot_marker.type = Marker.SPHERE
        robot_marker.action = Marker.ADD
        robot_marker.pose.position.x = robot_x
        robot_marker.pose.position.y = robot_y
        robot_marker.pose.position.z = 0.2
        robot_marker.pose.orientation.w = 1.0
        robot_marker.scale.x = 0.3
        robot_marker.scale.y = 0.3
        robot_marker.scale.z = 0.3
        robot_marker.color.r = 0.0
        robot_marker.color.g = 1.0
        robot_marker.color.b = 0.0
        robot_marker.color.a = 0.8
        robot_marker.lifetime.sec = 1
        
        marker_array.markers.append(robot_marker)
        
        # Rover path marker
        if len(self.rover_path) > 1:
            path_marker = Marker()
            path_marker.header.frame_id = "odom"
            path_marker.header.stamp = self.get_clock().now().to_msg()
            path_marker.ns = "rover_path"
            path_marker.id = 1
            path_marker.type = Marker.LINE_STRIP
            path_marker.action = Marker.ADD
            path_marker.scale.x = 0.05  # Line width
            path_marker.color.r = 0.0
            path_marker.color.g = 0.8
            path_marker.color.b = 0.8
            path_marker.color.a = 1.0
            path_marker.pose.orientation.w = 1.0
            
            for x, y, z in self.rover_path:
                p = Point32()
                p.x = x
                p.y = y
                p.z = z + 0.05  # Slightly above ground
                path_marker.points.append(p)
                
            marker_array.markers.append(path_marker)
        
        # Obstacle points markers - show fewer points for better performance
        for i, (x, y) in enumerate(obstacle_points):
            if i % 20 != 0:  # Only show every 20th point to reduce visual clutter
                continue
                
            obstacle_marker = Marker()
            obstacle_marker.header.frame_id = "odom"
            obstacle_marker.header.stamp = self.get_clock().now().to_msg()
            obstacle_marker.ns = "obstacle_points"
            obstacle_marker.id = i + 100  # Offset IDs to avoid conflicts
            obstacle_marker.type = Marker.SPHERE
            obstacle_marker.action = Marker.ADD
            obstacle_marker.pose.position.x = x
            obstacle_marker.pose.position.y = y
            obstacle_marker.pose.position.z = 0.1
            obstacle_marker.pose.orientation.w = 1.0
            obstacle_marker.scale.x = 0.1
            obstacle_marker.scale.y = 0.1
            obstacle_marker.scale.z = 0.1
            obstacle_marker.color.r = 1.0
            obstacle_marker.color.g = 0.0
            obstacle_marker.color.b = 0.0
            obstacle_marker.color.a = 0.8
            obstacle_marker.lifetime.sec = 1
            
            marker_array.markers.append(obstacle_marker)
        
        # Publish markers
        self.marker_publisher.publish(marker_array)

    def publish_map(self):
        """Publish occupancy grid map"""
        # Create occupancy grid message
        grid_msg = OccupancyGrid()
        grid_msg.header.stamp = self.get_clock().now().to_msg()
        grid_msg.header.frame_id = 'odom'
        
        grid_msg.info.resolution = self.map_resolution
        grid_msg.info.width = self.map_width
        grid_msg.info.height = self.map_height
        grid_msg.info.origin.position.x = self.map_origin_x
        grid_msg.info.origin.position.y = self.map_origin_y
        
        # Flatten the grid for ROS message
        grid_msg.data = self.occupancy_grid.flatten().tolist()
        
        # Publish occupancy grid
        self.occupancy_grid_publisher.publish(grid_msg)
        self.get_logger().info('Published terrain map')

def main(args=None):
    rclpy.init(args=args)
    rover_mapping = RoverMapping()
    
    try:
        rclpy.spin(rover_mapping)
    except KeyboardInterrupt:
        rover_mapping.get_logger().info('Mapping stopped by user')
    finally:
        rover_mapping.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main() 