#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
import threading

class ScanDebugger(Node):
    def __init__(self):
        super().__init__('scan_debugger')
        self.received = False
        self.subscription = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            10)
        self.timer = self.create_timer(5.0, self.check_scan)

    def scan_callback(self, msg):
        self.received = True
        self.get_logger().info('Received LaserScan message on /scan.')
        self.destroy_node()

    def check_scan(self):
        if not self.received:
            self.get_logger().warn('No LaserScan messages received on /scan after 5 seconds! LIDAR may not be working.')
        self.destroy_node()

def main(args=None):
    rclpy.init(args=args)
    node = ScanDebugger()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main() 