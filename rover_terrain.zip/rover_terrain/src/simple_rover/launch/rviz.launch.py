from launch import LaunchDescription
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
import os

def generate_launch_description():
    # Package paths
    pkg_simple_rover = FindPackageShare('simple_rover').find('simple_rover')
    
    # RViz configuration file
    rviz_config_path = os.path.join(pkg_simple_rover, 'config', 'rviz_config.rviz')
    
    # Launch RViz
    rviz = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        arguments=['-d', rviz_config_path],
        output='screen'
    )

    return LaunchDescription([
        rviz
    ]) 