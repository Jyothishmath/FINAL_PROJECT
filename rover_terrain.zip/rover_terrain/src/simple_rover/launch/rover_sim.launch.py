from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, ExecuteProcess
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
import os

def generate_launch_description():
    # Package paths
    pkg_simple_rover = FindPackageShare('simple_rover').find('simple_rover')
    
    # Configuration
    urdf_path = os.path.join(pkg_simple_rover, 'urdf', 'simple_rover.urdf')
    world_path = os.path.join(pkg_simple_rover, 'worlds', 'mars_world.world')
    
    # Launch Gazebo with Mars terrain
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            FindPackageShare("gazebo_ros").find("gazebo_ros"),
            '/launch/gazebo.launch.py'
        ]),
        launch_arguments={
            'world': world_path,
            'verbose': 'true'
        }.items()
    )
    
    # Robot state publisher
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[{
            'robot_description': open(urdf_path, 'r').read(),
            'use_sim_time': True,
            'publish_frequency': 50.0,
            'frame_prefix': ''
        }]
    )
    
    # Joint state publisher GUI
    joint_state_publisher = Node(
        package='joint_state_publisher_gui',
        executable='joint_state_publisher_gui',
        name='joint_state_publisher_gui',
        output='screen',
        parameters=[{'use_sim_time': True}]
    )
    
    # TF static transform publishers
    world_to_map = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='world_to_map',
        arguments=['0', '0', '0', '0', '0', '0', 'world', 'map']
    )
    
    map_to_odom = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='map_to_odom',
        arguments=['0', '0', '0', '0', '0', '0', 'map', 'odom']
    )

    # Add base_footprint transform
    odom_to_base_footprint = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='odom_to_base_footprint',
        arguments=['0', '0', '0', '0', '0', '0', 'odom', 'base_footprint']
    )

    # Add base_footprint to base_link transform
    base_footprint_to_base_link = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='base_footprint_to_base_link',
        arguments=['0', '0', '0.1', '0', '0', '0', 'base_footprint', 'base_link']
    )

    # SLAM Toolbox
    slam_toolbox = Node(
        package='slam_toolbox',
        executable='async_slam_toolbox_node',
        name='slam_toolbox',
        output='screen',
        parameters=[{
            'use_sim_time': True,
            'base_frame': 'base_link',
            'odom_frame': 'odom',
            'map_frame': 'map',
            'publish_period': 0.01,
            'scan_topic': '/scan',
            'resolution': 0.05,
            'map_update_interval': 5.0,
            'max_laser_range': 20.0,
            'max_update_rate': 10.0
        }]
    )
    
    # Spawn rover higher above the terrain
    spawn_entity = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        name='spawn_entity',
        output='screen',
        arguments=[
            '-entity', 'simple_rover',
            '-file', urdf_path,
            '-x', '0.0',
            '-y', '0.0', 
            '-z', '1.0'  # Adjusted height to match terrain level
        ]
    )

    # RViz with config
    rviz = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen',
        arguments=['-d', os.path.join(pkg_simple_rover, 'config', 'rviz_config.rviz')],
        parameters=[{'use_sim_time': True}]
    )

    return LaunchDescription([
        gazebo,
        robot_state_publisher,
        joint_state_publisher,
        world_to_map,
        map_to_odom,
        odom_to_base_footprint,
        base_footprint_to_base_link,
        slam_toolbox,
        spawn_entity,
        rviz
    ]) 