from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, ExecuteProcess, RegisterEventHandler, SetEnvironmentVariable
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.event_handlers import OnProcessExit
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
import os

def generate_launch_description():
    # Use sim time
    use_sim_time = LaunchConfiguration('use_sim_time', default='true')
    
    # Package paths
    pkg_simple_rover = FindPackageShare('simple_rover').find('simple_rover')
    workspace_path = os.path.abspath(os.path.join(pkg_simple_rover, '..', '..', '..'))
    
    # Debug output for model path
    print(f"Workspace path: {workspace_path}")
    print(f"Models path: {os.path.join(workspace_path, 'models')}")
    
    # Set Gazebo model path to include the Mars terrain model
    gazebo_model_path = os.path.join(workspace_path, 'models')
    os.environ['GAZEBO_MODEL_PATH'] = f"{gazebo_model_path}:{os.environ.get('GAZEBO_MODEL_PATH', '')}"
    
    set_gazebo_model_path = SetEnvironmentVariable(
        name='GAZEBO_MODEL_PATH',
        value=os.environ['GAZEBO_MODEL_PATH']
    )
    
    # Configuration
    urdf_path = os.path.join(pkg_simple_rover, 'urdf', 'simple_rover.urdf')
    world_path = os.path.join(pkg_simple_rover, 'worlds', 'mars_terrain_world.world')
    
    # Kill any existing Gazebo processes to avoid port conflicts
    kill_gazebo = ExecuteProcess(
        cmd=['pkill', '-f', 'gazebo'],
        name='kill_gazebo',
        output='screen'
    )
    
    # Launch Gazebo with Mars terrain
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            FindPackageShare("gazebo_ros").find("gazebo_ros"),
            '/launch/gazebo.launch.py'
        ]),
        launch_arguments={
            'world': world_path,
            'verbose': 'true'
        }.items()
    )
    
    # Robot state publisher
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[{'robot_description': open(urdf_path, 'r').read(), 'use_sim_time': True}]
    )
    
    # Spawn rover
    spawn_entity = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=[
            '-entity', 'simple_rover',
            '-file', urdf_path,
            '-x', '0.0',
            '-y', '0.0',
            '-z', '15.0',  # Higher position to ensure it's above the terrain
            '-R', '0.0',
            '-P', '0.0',
            '-Y', '0.0'
        ],
        output='screen'
    )
    
    # Joint state publisher
    joint_state_publisher = Node(
        package='joint_state_publisher',
        executable='joint_state_publisher',
        name='joint_state_publisher',
        parameters=[{'use_sim_time': True}],
        output='screen'
    )
    
    # TF static transform publishers
    tf_footprint_base = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='tf_footprint_base',
        arguments=['0', '0', '0', '0', '0', '0', 'base_link', 'base_footprint']
    )
    
    lidar_tf_publisher = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='tf_base_lidar',
        arguments=['0', '0', '0.225', '0', '0', '0', 'base_link', 'lidar_link']
    )
    
    camera_tf_publisher = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='tf_base_camera',
        arguments=['0.25', '0', '0.15', '0', '0', '0', 'base_link', 'camera_link']
    )
    
    odom_to_base_footprint = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='tf_odom_base_footprint',
        arguments=['0', '0', '0', '0', '0', '0', 'odom', 'base_footprint']
    )
    
    # Rover navigation node
    rover_navigation = Node(
        package='simple_rover',
        executable='rover_navigation.py',
        name='rover_navigation',
        output='screen'
    )
    
    # Rover mapping node
    rover_mapping = Node(
        package='simple_rover',
        executable='rover_mapping.py',
        name='rover_mapping',
        output='screen'
    )
    
    # Launch RViz with specific config
    rviz = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        arguments=['-d', os.path.join(pkg_simple_rover, 'config', 'rviz_config.rviz')],
        parameters=[{'use_sim_time': True}],
        output='screen'
    )

    return LaunchDescription([
        set_gazebo_model_path,
        kill_gazebo,
        gazebo,
        robot_state_publisher,
        joint_state_publisher,
        tf_footprint_base,
        lidar_tf_publisher,
        camera_tf_publisher,
        odom_to_base_footprint,
        spawn_entity,
        rover_navigation,
        rover_mapping,
        rviz
    ]) 